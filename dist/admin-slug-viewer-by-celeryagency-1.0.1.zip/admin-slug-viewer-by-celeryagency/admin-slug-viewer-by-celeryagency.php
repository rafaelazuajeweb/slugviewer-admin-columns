<?php
/**
 * Plugin Name: Admin Slug Viewer by CeleryAgency
 * Description: Display slug columns for Posts, Pages, and Custom Post Types in your WordPress admin with sortable columns and per-type control.
 * Version:     1.0.1
 * Author:      Celery Software LLC
 * Author URI:  https://celeryagency.com/
 * License:     GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: admin-slug-viewer-by-celeryagency
 * Requires at least: 5.8
 * Requires PHP: 7.4
 *
 * @package Admin_Slug_Viewer_By_CeleryAgency
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'CASV_VERSION', '1.0.1' );
define( 'CASV_PLUGIN_FILE', __FILE__ );
define( 'CASV_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'CASV_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

/**
 * Return the post types enabled for the Slug column.
 *
 * The legacy option is migrated automatically for existing local installs.
 *
 * @return string[] Enabled post type slugs.
 */
function casv_get_enabled_post_types() {
	$enabled_types = get_option( 'casv_enabled_post_types', false );

	if ( false === $enabled_types ) {
		$legacy_types  = get_option( 'asp_enabled_post_types', false );
		$enabled_types = is_array( $legacy_types ) ? $legacy_types : array( 'post', 'page' );
		$enabled_types = array_values( array_unique( array_map( 'sanitize_key', $enabled_types ) ) );

		add_option( 'casv_enabled_post_types', $enabled_types );
	}

	return is_array( $enabled_types ) ? $enabled_types : array( 'post', 'page' );
}

/**
 * Set the plugin defaults on activation.
 *
 * @return void
 */
function casv_activate() {
	casv_get_enabled_post_types();
}
register_activation_hook( __FILE__, 'casv_activate' );

/**
 * Load the plugin in the WordPress administration area.
 *
 * @return void
 */
function casv_init() {
	if ( ! is_admin() ) {
		return;
	}

	require_once CASV_PLUGIN_DIR . 'includes/class-casv-columns.php';
	require_once CASV_PLUGIN_DIR . 'includes/class-casv-settings.php';

	new CASV_Columns();
	new CASV_Settings();
}
add_action( 'plugins_loaded', 'casv_init' );
