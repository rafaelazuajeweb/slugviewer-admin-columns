<?php
/**
 * Fired when the plugin is uninstalled.
 *
 * @package Admin_Slug_Viewer_By_CeleryAgency
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

delete_option( 'casv_enabled_post_types' );
delete_option( 'asp_enabled_post_types' );
